Libraries Needed :

sklearn, pandas, numpy, csv, math and datetime

Simple algorithm:

Decision tree.

Code in python,

can be run as:

python hackRank-emailOpen-solution.py

You can see the ipython file : 

hackRank-emailOpen-solution.ipynb

for more information.

And the hackRank-emailOpen-solution.html with the ipython file.
